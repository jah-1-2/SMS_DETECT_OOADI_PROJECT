package com.example.scam.models;

public class ApiResponse {
}
