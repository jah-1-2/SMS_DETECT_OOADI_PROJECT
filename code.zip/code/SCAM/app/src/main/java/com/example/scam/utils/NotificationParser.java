package com.example.scam.utils;

public class NotificationParser {
}
