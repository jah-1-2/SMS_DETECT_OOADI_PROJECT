package com.example.scam.network;

public class ApiService {
}
