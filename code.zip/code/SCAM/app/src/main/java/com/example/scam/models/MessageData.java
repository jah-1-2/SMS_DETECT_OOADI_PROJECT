package com.example.scam.models;

public class MessageData {
}
