package com.example.scam.receivers;

public class SmsReceiver {
}
